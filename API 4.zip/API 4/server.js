const express = require('express');
const app = express();

app.use(express.json()); // Middleware to parse JSON

let users = [
    { id: 1, name: "Alice", age: 25 },
    { id: 2, name: "Bob", age: 30 }
];

// GET request - Fetch users
app.get('/users', (req, res) => {
    res.json(users);
});  

// POST request - Add a new user
app.post('/users', (req, res) => {
    const newUser = req.body;
    users.push(newUser);
    res.status(201).json(newUser);
});

// PUT request - Update a user
app.put('/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    let user = users.find(u => u.id === userId);
    if (!user) return res.status(404).send('User not found');
    
    user.name = req.body.name;
    user.age = req.body.age;
    res.json(user);
});

// DELETE request - Remove a user
app.delete('/users/:id', (req, res) => {
    users = users.filter(u => u.id !== parseInt(req.params.id));
    res.json({ message: 'User deleted' });
});

app.listen(3000, () => console.log('Server running on port 3000'));
