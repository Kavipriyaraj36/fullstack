const fs = require('fs');

console.log("Start of script");

// Synchronous file read (Blocking)
try {
    const data = fs.readFileSync('example.txt', 'utf8'); // Blocks execution
    console.log("Synchronous Read:", data);
} catch (err) {
    console.error("Error in synchronous read:", err.message);
}

console.log("After Synchronous Read");

// Asynchronous file read (Non-Blocking)
fs.readFile('example.txt', 'utf8', (err, data) => {
    if (err) {
        console.error("Error in asynchronous read:", err.message);
        return;
    }
    console.log("Asynchronous Read:", data);
});

console.log("End of script");

