const express = require('express');
const app = express();
const path = require('path');

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Sample Data
const users = [
    { name: "Alice", age: 25 },
    { name: "Bob", age: 30 },
    { name: "Charlie", age: 22 }
];

// Route for the homepage
app.get('/', (req, res) => {
    res.send('<h1>Welcome to the Express Server!</h1>');
});

// Route to render the EJS template
app.get('/users', (req, res) => {
    res.render('users', { users });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

